"""
generate_data.py
Simulated 1% sample of a food-delivery marketplace's ad logs (SQLite).
All data is SYNTHETIC. Deterministic (seed=42). Run: python generate_data.py
"""
import sqlite3, os
from datetime import date, timedelta
import numpy as np
import pandas as pd

SEED = 42
rng = np.random.default_rng(SEED)

DATA_START, DATA_END = date(2026, 1, 1), date(2026, 9, 30)
EXP_START, EXP_END = date(2026, 9, 7), date(2026, 9, 27)   # A/B test window
EXP_SLOT = 3                                               # restaurant_listing
SAMPLE_RATE = 0.01                                         # we simulate a 1% log sample
DEMAND_SCALE = 3.0                                         # volume knob

# slot_id, name, floor_cpm, base_ctr, capacity/day (sample units)
SLOTS = [
    (1, "home_banner",        120, 0.010,  700),
    (2, "search_top",         160, 0.020,  900),
    (3, "restaurant_listing", 100, 0.018, 1200),
    (4, "checkout_upsell",     90, 0.025,  600),
]
CLEAR_MULT = 1.45  # clearing price over floor at 1 bidder

# category: ctr_mult, click->order cvr, AOV, cpm_mult, mean advertiser lifetime (days)
CATS = {
    "QSR Chains":        (1.25, 0.100, 420, 1.15, 260),
    "Local Restaurants": (1.00, 0.090, 380, 0.85,  75),
    "Beverages":         (1.10, 0.070, 240, 1.00, 170),
    "Snacks & FMCG":     (0.90, 0.060, 300, 1.05, 190),
    "Dairy & Bakery":    (1.00, 0.080, 280, 0.90, 160),
    "Desserts & Sweets": (1.15, 0.070, 350, 0.95, 130),
    "Health Foods":      (0.80, 0.050, 520, 1.00, 110),
    "Personal Care":     (0.70, 0.030, 450, 1.10, 150),
}
CAT_NAMES = list(CATS)
CAT_PROB = [0.14, 0.24, 0.12, 0.14, 0.10, 0.10, 0.08, 0.08]

HOUR_P = np.array([1,1,1,1,1,1,2,3,4,5,7,10,12,10,6,4,5,8,11,12,11,8,4,2], float)
HOUR_P /= HOUR_P.sum()

# ---------------- advertisers ----------------
N_LEGACY, N_NEW = 30, 100
n_adv = N_LEGACY + N_NEW
legacy_signup = [date(2025, 10, 1) + timedelta(days=int(d)) for d in rng.integers(0, 92, N_LEGACY)]
new_signup = [date(2026, 1, 1) + timedelta(days=int(d)) for d in rng.integers(0, 244, N_NEW)]
signup = legacy_signup + new_signup
cat_idx = rng.choice(len(CAT_NAMES), size=n_adv, p=CAT_PROB)
cat_of = [CAT_NAMES[i] for i in cat_idx]
life_days = np.array([rng.exponential(CATS[c][4]) for c in cat_of])
active_until = [signup[i] + timedelta(days=int(life_days[i])) for i in range(n_adv)]
budget_factor = rng.lognormal(0, 0.8, n_adv)
budget_factor /= budget_factor.mean()
quality = rng.lognormal(0, 0.20, n_adv)       # CTR quality
cvr_factor = rng.lognormal(0, 0.15, n_adv)    # conversion quality
pref = rng.dirichlet([1.2, 3.6, 4.0, 1.8], n_adv)     # slot preference per advertiser

D0 = 250.0  # base desired impressions/day per advertiser (sample units)
monthly_budget = np.round(budget_factor * D0 * 30 * 0.27 / SAMPLE_RATE, -4)

advertisers = pd.DataFrame({
    "advertiser_id": np.arange(1, n_adv + 1),
    "advertiser_name": [f"Brand_{i:03d}" for i in range(1, n_adv + 1)],
    "category": cat_of,
    "signup_date": [d.isoformat() for d in signup],
    "monthly_budget_inr": monthly_budget.astype(int),
})
slots_df = pd.DataFrame(SLOTS, columns=["slot_id", "slot_name", "floor_cpm", "base_ctr", "cap"])[
    ["slot_id", "slot_name", "floor_cpm"]]

cat_ctr = np.array([CATS[c][0] for c in cat_of])
cat_cvr = np.array([CATS[c][1] for c in cat_of])
cat_aov = np.array([CATS[c][2] for c in cat_of])
cat_cpm = np.array([CATS[c][3] for c in cat_of])
signup_arr = np.array(signup, dtype="datetime64[D]")
until_arr = np.array(active_until, dtype="datetime64[D]")

# ---------------- simulate day by day ----------------
inv_rows, imp_frames = [], []
n_days = (DATA_END - DATA_START).days + 1
for t in range(n_days):
    d = DATA_START + timedelta(days=t)
    d64 = np.datetime64(d)
    dow = d.weekday()
    wk_cap = 1.15 if dow >= 4 else 1.0                   # Fri-Sun traffic uplift
    growth = 1.0 + 0.10 * t / n_days                     # platform traffic growth
    active = (signup_arr <= d64) & (until_arr >= d64) & (rng.random(n_adv) < 0.92)
    ramp = np.minimum(1.0, ((d64 - signup_arr).astype(int) + 1) / 14.0)
    desired_i = D0 * budget_factor * ramp * rng.lognormal(0, 0.25, n_adv) * active

    for (sid, sname, floor, bctr, cap) in SLOTS:
        avail = int(cap * DEMAND_SCALE * wk_cap * growth * rng.uniform(0.95, 1.05))
        want = desired_i * pref[:, sid - 1]
        demand = want.sum()
        filled = int(min(avail, round(demand)))
        inv_rows.append((d.isoformat(), sid, avail, filled))
        if filled == 0:
            continue
        counts = rng.multinomial(filled, want / demand)
        adv_ix = np.repeat(np.arange(n_adv), counts)
        n = adv_ix.size
        pressure = float(np.clip(demand / avail, 0.3, 2.5))
        bidders = np.clip(1 + rng.poisson(2.0 * pressure, n), 1, 8)
        cpm = floor * CLEAR_MULT * (1 + 0.08 * (bidders - 1)) * cat_cpm[adv_ix] * rng.lognormal(0, 0.12, n)
        cpm = np.round(np.maximum(cpm, floor), 2)
        hours = rng.choice(24, size=n, p=HOUR_P)
        secs = hours * 3600 + rng.integers(0, 3600, n)
        ts = (np.datetime64(d, "s") + secs.astype("timedelta64[s]")).astype("datetime64[s]")
        if sid == EXP_SLOT and EXP_START <= d <= EXP_END:
            variant = np.where(rng.random(n) < 0.5, "treatment", "control").astype(object)
        else:
            variant = np.full(n, None, dtype=object)
        imp_frames.append(pd.DataFrame({
            "ts": ts.astype(str), "date": d.isoformat(), "advertiser_id": adv_ix + 1,
            "slot_id": sid, "cpm_paid": cpm, "num_bidders": bidders, "variant": variant,
        }))

impressions = pd.concat(imp_frames, ignore_index=True)
impressions.insert(0, "impression_id", np.arange(1, len(impressions) + 1))
inventory = pd.DataFrame(inv_rows, columns=["date", "slot_id", "impressions_available", "impressions_filled"])

# ---------------- clicks ----------------
slot_ctr = {s[0]: s[3] for s in SLOTS}
adv_ix = impressions["advertiser_id"].to_numpy() - 1
base = impressions["slot_id"].map(slot_ctr).to_numpy()
is_treat = (impressions["variant"] == "treatment").to_numpy()
p_click = base * cat_ctr[adv_ix] * quality[adv_ix] * np.where(is_treat, 1.16, 1.0)   # true CTR lift +16%
clicked = rng.random(len(impressions)) < p_click
clicks = impressions.loc[clicked, ["impression_id", "ts"]].copy()
clicks["clicked_at"] = (pd.to_datetime(clicks["ts"]) + pd.to_timedelta(rng.integers(1, 30, len(clicks)), unit="s")).dt.strftime("%Y-%m-%d %H:%M:%S")
clicks = clicks[["impression_id", "clicked_at"]].reset_index(drop=True)
clicks.insert(0, "click_id", np.arange(1, len(clicks) + 1))

# ---------------- orders ----------------
c_adv = adv_ix[clicked]
c_treat = is_treat[clicked]
p_order = cat_cvr[c_adv] * cvr_factor[c_adv] * np.where(c_treat, 0.96, 1.0)           # true CVR dip -4%
ordered = rng.random(len(clicks)) < p_order
o = clicks.loc[ordered].copy()
oi = c_adv[ordered]
o["advertiser_id"] = oi + 1
sigma = 0.35
o["order_value"] = np.round(rng.lognormal(np.log(cat_aov[oi]) - sigma**2 / 2, sigma)).astype(int)
o["ordered_at"] = (pd.to_datetime(o["clicked_at"]) + pd.to_timedelta(rng.integers(30, 1800, len(o)), unit="s")).dt.strftime("%Y-%m-%d %H:%M:%S")
orders = o[["click_id", "advertiser_id", "ordered_at", "order_value"]].reset_index(drop=True)
orders.insert(0, "order_id", np.arange(1, len(orders) + 1))

# ---------------- write SQLite ----------------
DB = "ads.db"
if os.path.exists(DB):
    os.remove(DB)
con = sqlite3.connect(DB)
advertisers.to_sql("advertisers", con, index=False)
slots_df.to_sql("slots", con, index=False)
inventory.to_sql("inventory", con, index=False)
impressions[["impression_id", "ts", "date", "advertiser_id", "slot_id", "cpm_paid", "num_bidders", "variant"]].to_sql("impressions", con, index=False)
clicks.to_sql("clicks", con, index=False)
orders.to_sql("orders", con, index=False)
cur = con.cursor()
for stmt in [
    "CREATE INDEX ix_imp_date ON impressions(date)",
    "CREATE INDEX ix_imp_adv ON impressions(advertiser_id)",
    "CREATE INDEX ix_imp_slot ON impressions(slot_id)",
    "CREATE INDEX ix_clk_imp ON clicks(impression_id)",
    "CREATE INDEX ix_ord_clk ON orders(click_id)",
    "CREATE INDEX ix_inv_date ON inventory(date)",
]:
    cur.execute(stmt)
con.commit()
con.close()

print(f"advertisers={len(advertisers):,} impressions={len(impressions):,} clicks={len(clicks):,} orders={len(orders):,}")
print(f"sample spend INR={(impressions.cpm_paid.sum()/1000):,.0f} order revenue INR={orders.order_value.sum():,.0f}")
