"""
run_analysis.py
Runs every query in queries.sql against ads.db, saves CSVs to results/, and computes the
A/B test readout (two-proportion z-test, CI on lift, guardrail check, sample-size estimate).
Run: python run_analysis.py
"""
import os, re, json, math, sqlite3
import pandas as pd

os.makedirs("results", exist_ok=True)
con = sqlite3.connect("ads.db")

sql_text = open("queries.sql").read()
blocks = re.split(r"^-- name: (\w+)\s*$", sql_text, flags=re.M)
queries = {blocks[i]: blocks[i + 1].strip() for i in range(1, len(blocks), 2)}

results = {}
for name, q in queries.items():
    df = pd.read_sql(q, con)
    df.to_csv(f"results/{name}.csv", index=False)
    results[name] = df
    print(f"\n=== {name} ({len(df)} rows) ===")
    print(df.head(12).to_string(index=False))


# ---------------- A/B test readout ----------------
def norm_cdf(x):
    return 0.5 * math.erfc(-x / math.sqrt(2))

def two_prop_z(x1, n1, x2, n2):
    """x1/n1 = control, x2/n2 = treatment. Returns diff, z, two-sided p, 95% CI on diff (unpooled)."""
    p1, p2 = x1 / n1, x2 / n2
    pooled = (x1 + x2) / (n1 + n2)
    se_pool = math.sqrt(pooled * (1 - pooled) * (1 / n1 + 1 / n2))
    z = (p2 - p1) / se_pool
    p = 2 * (1 - norm_cdf(abs(z)))
    se_unp = math.sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
    return p2 - p1, z, p, (p2 - p1 - 1.96 * se_unp, p2 - p1 + 1.96 * se_unp)

def n_per_arm(p_base, rel_lift, alpha_z=1.96, power_z=0.8416):
    p2 = p_base * (1 + rel_lift)
    pbar = (p_base + p2) / 2
    num = (alpha_z * math.sqrt(2 * pbar * (1 - pbar)) + power_z * math.sqrt(p_base * (1 - p_base) + p2 * (1 - p2))) ** 2
    return math.ceil(num / (p2 - p_base) ** 2)

ab = results["q6_ab_test_readout"].set_index("variant")
c, t = ab.loc["control"], ab.loc["treatment"]
d, z, p, ci = two_prop_z(c.clicks, c.impressions, t.clicks, t.impressions)
ctr_c, ctr_t = c.clicks / c.impressions, t.clicks / t.impressions
d2, z2, p2, ci2 = two_prop_z(c.orders, c.clicks, t.orders, t.clicks)           # guardrail: click->order
d3, z3, p3, ci3 = two_prop_z(c.orders, c.impressions, t.orders, t.impressions)  # orders per impression

out = {
    "ctr_control_pct": round(100 * ctr_c, 3), "ctr_treatment_pct": round(100 * ctr_t, 3),
    "ctr_rel_lift_pct": round(100 * (ctr_t / ctr_c - 1), 1),
    "ctr_rel_lift_ci95_pct": [round(100 * ci[0] / ctr_c, 1), round(100 * ci[1] / ctr_c, 1)],
    "ctr_z": round(z, 2), "ctr_p_value": float(f"{p:.2g}"),
    "guardrail_click_to_order_control_pct": round(100 * c.orders / c.clicks, 2),
    "guardrail_click_to_order_treatment_pct": round(100 * t.orders / t.clicks, 2),
    "guardrail_c2o_p_value": round(p2, 3),
    "orders_per_1k_imps_control": round(1000 * c.orders / c.impressions, 3),
    "orders_per_1k_imps_treatment": round(1000 * t.orders / t.impressions, 3),
    "orders_per_imp_p_value": round(p3, 3),
    "n_per_arm_used": [int(c.impressions), int(t.impressions)],
    "clicks_per_arm_needed_to_detect_15pct_rel_drop_in_click_to_order_80pct_power": n_per_arm(c.orders / c.clicks, -0.15),
    "clicks_per_arm_available": [int(c.clicks), int(t.clicks)],
    "cpm_control": float(c.cpm), "cpm_treatment": float(t.cpm),
}
json.dump(out, open("results/ab_test_stats.json", "w"), indent=2)
print("\n=== A/B readout ===")
print(json.dumps(out, indent=2))
