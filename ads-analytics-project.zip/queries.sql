-- Ads Performance & Auction Health Analytics (SQLite dialect; ports to Postgres with minor date-function edits)
-- Data = SIMULATED 1% sample of ad logs. Full weeks only: Mon 2026-01-05 .. Sun 2026-09-27.
-- Money in INR. Spend (platform ad revenue) = SUM(cpm_paid)/1000. ROAS = attributed order value / spend.

-- name: q1_weekly_kpis
-- Weekly ads P&L: revenue, CPM, CTR, fill rate, advertiser count, ROAS  (JD: dashboards & KPI reporting)
WITH base AS (
  SELECT impression_id, advertiser_id, cpm_paid,
         date(date, '-' || ((CAST(strftime('%w', date) AS INTEGER) + 6) % 7) || ' days') AS week_start
  FROM impressions
  WHERE date BETWEEN '2026-01-05' AND '2026-09-27'
),
perf AS (
  SELECT b.week_start,
         COUNT(*)                          AS impressions,
         COUNT(c.click_id)                 AS clicks,
         COUNT(o.order_id)                 AS orders,
         ROUND(SUM(b.cpm_paid) / 1000.0, 2) AS revenue,
         COALESCE(SUM(o.order_value), 0)   AS attributed_order_value,
         COUNT(DISTINCT b.advertiser_id)   AS active_advertisers
  FROM base b
  LEFT JOIN clicks c ON c.impression_id = b.impression_id
  LEFT JOIN orders o ON o.click_id = c.click_id
  GROUP BY b.week_start
),
inv AS (
  SELECT date(date, '-' || ((CAST(strftime('%w', date) AS INTEGER) + 6) % 7) || ' days') AS week_start,
         SUM(impressions_available) AS available, SUM(impressions_filled) AS filled
  FROM inventory
  WHERE date BETWEEN '2026-01-05' AND '2026-09-27'
  GROUP BY 1
)
SELECT p.week_start, p.impressions, p.clicks, p.orders, p.revenue, p.attributed_order_value,
       p.active_advertisers, i.available, i.filled,
       ROUND(100.0 * p.clicks / p.impressions, 3)               AS ctr_pct,
       ROUND(1000.0 * p.revenue / p.impressions, 2)             AS cpm,
       ROUND(100.0 * i.filled / i.available, 1)                 AS fill_rate_pct,
       ROUND(p.attributed_order_value / p.revenue, 2)           AS roas
FROM perf p JOIN inv i USING (week_start)
ORDER BY p.week_start;

-- name: q2_category_performance
-- Which categories to grow or fix  (JD: advertiser & category insights)
WITH cat AS (
  SELECT a.category,
         COUNT(DISTINCT i.advertiser_id)       AS advertisers,
         COUNT(*)                              AS impressions,
         COUNT(c.click_id)                     AS clicks,
         COUNT(o.order_id)                     AS orders,
         ROUND(SUM(i.cpm_paid) / 1000.0, 2)    AS spend,
         COALESCE(SUM(o.order_value), 0)       AS attributed_order_value
  FROM impressions i
  JOIN advertisers a ON a.advertiser_id = i.advertiser_id
  LEFT JOIN clicks c ON c.impression_id = i.impression_id
  LEFT JOIN orders o ON o.click_id = c.click_id
  GROUP BY a.category
)
SELECT category, advertisers, impressions, clicks, orders, spend, attributed_order_value,
       ROUND(100.0 * clicks / impressions, 3)           AS ctr_pct,
       ROUND(1000.0 * spend / impressions, 2)           AS cpm,
       ROUND(100.0 * orders / clicks, 2)                AS click_to_order_pct,
       ROUND(attributed_order_value / spend, 2)         AS roas,
       ROUND(100.0 * spend / SUM(spend) OVER (), 1)     AS spend_share_pct,
       RANK() OVER (ORDER BY attributed_order_value / spend DESC) AS roas_rank
FROM cat
ORDER BY roas DESC;

-- name: q3_slot_auction_health
-- Inventory utilisation + auction health by placement  (JD: inventory utilisation, auction health)
WITH inv AS (
  SELECT slot_id, SUM(impressions_available) AS available, SUM(impressions_filled) AS filled
  FROM inventory GROUP BY slot_id
),
auc AS (
  SELECT slot_id,
         COUNT(*)                                            AS impressions,
         ROUND(AVG(num_bidders), 2)                          AS avg_bidders,
         ROUND(100.0 * AVG(CASE WHEN num_bidders = 1 THEN 1.0 ELSE 0 END), 1) AS single_bidder_pct,
         ROUND(1000.0 * SUM(cpm_paid) / 1000.0 / COUNT(*), 2) AS cpm
  FROM impressions GROUP BY slot_id
)
SELECT s.slot_name, s.floor_cpm, inv.available, inv.filled,
       ROUND(100.0 * inv.filled / inv.available, 1)  AS fill_rate_pct,
       auc.avg_bidders, auc.single_bidder_pct, auc.cpm,
       ROUND(100.0 * (auc.cpm / s.floor_cpm - 1), 1) AS price_over_floor_pct
FROM slots s JOIN inv USING (slot_id) JOIN auc USING (slot_id)
ORDER BY fill_rate_pct DESC;

-- name: q3b_monthly_fill_by_slot
-- Fill-rate trend by placement (where is inventory sold out vs. under-used)
SELECT substr(i.date, 1, 7) AS month, s.slot_name,
       ROUND(100.0 * SUM(i.impressions_filled) / SUM(i.impressions_available), 1) AS fill_rate_pct
FROM inventory i JOIN slots s USING (slot_id)
GROUP BY 1, 2
ORDER BY 1, 2;

-- name: q4_retention_by_cohort
-- Share of each signup-month cohort still spending in the week starting day 30 / 60 / 90 after signup
-- Cohort limited to signups on/before 2026-06-26 so the day-90 window is fully observed.
WITH adv_days AS (SELECT DISTINCT advertiser_id, date FROM impressions),
cohort AS (
  SELECT advertiser_id, signup_date, substr(signup_date, 1, 7) AS cohort_month
  FROM advertisers WHERE signup_date BETWEEN '2026-01-01' AND '2026-06-26'
),
ret AS (
  SELECT c.advertiser_id, c.cohort_month,
         MAX(CASE WHEN julianday(d.date) - julianday(c.signup_date) BETWEEN 30 AND 36 THEN 1 ELSE 0 END) AS r30,
         MAX(CASE WHEN julianday(d.date) - julianday(c.signup_date) BETWEEN 60 AND 66 THEN 1 ELSE 0 END) AS r60,
         MAX(CASE WHEN julianday(d.date) - julianday(c.signup_date) BETWEEN 90 AND 96 THEN 1 ELSE 0 END) AS r90
  FROM cohort c LEFT JOIN adv_days d ON d.advertiser_id = c.advertiser_id
  GROUP BY c.advertiser_id, c.cohort_month
)
SELECT cohort_month, COUNT(*) AS advertisers,
       SUM(r30) AS retained_d30, SUM(r60) AS retained_d60, SUM(r90) AS retained_d90,
       ROUND(100.0 * AVG(r30), 1) AS d30_pct, ROUND(100.0 * AVG(r60), 1) AS d60_pct, ROUND(100.0 * AVG(r90), 1) AS d90_pct
FROM ret
GROUP BY cohort_month
ORDER BY cohort_month;

-- name: q4b_retention_by_category
-- Same retention definition, cut by category (who churns?)
WITH adv_days AS (SELECT DISTINCT advertiser_id, date FROM impressions),
cohort AS (
  SELECT advertiser_id, signup_date, category
  FROM advertisers WHERE signup_date BETWEEN '2026-01-01' AND '2026-06-26'
),
ret AS (
  SELECT c.advertiser_id, c.category,
         MAX(CASE WHEN julianday(d.date) - julianday(c.signup_date) BETWEEN 30 AND 36 THEN 1 ELSE 0 END) AS r30,
         MAX(CASE WHEN julianday(d.date) - julianday(c.signup_date) BETWEEN 60 AND 66 THEN 1 ELSE 0 END) AS r60,
         MAX(CASE WHEN julianday(d.date) - julianday(c.signup_date) BETWEEN 90 AND 96 THEN 1 ELSE 0 END) AS r90
  FROM cohort c LEFT JOIN adv_days d ON d.advertiser_id = c.advertiser_id
  GROUP BY c.advertiser_id, c.category
)
SELECT category, COUNT(*) AS advertisers,
       SUM(r30) AS retained_d30, SUM(r60) AS retained_d60, SUM(r90) AS retained_d90,
       ROUND(100.0 * AVG(r30), 1) AS d30_pct, ROUND(100.0 * AVG(r60), 1) AS d60_pct, ROUND(100.0 * AVG(r90), 1) AS d90_pct
FROM ret
GROUP BY category
ORDER BY d90_pct DESC;

-- name: q5_top_advertisers_per_category
-- Top 3 advertisers per category by spend (window function)
WITH adv AS (
  SELECT a.category, a.advertiser_name,
         ROUND(SUM(i.cpm_paid) / 1000.0, 2) AS spend,
         COALESCE(SUM(o.order_value), 0)    AS attributed_order_value
  FROM impressions i
  JOIN advertisers a ON a.advertiser_id = i.advertiser_id
  LEFT JOIN clicks c ON c.impression_id = i.impression_id
  LEFT JOIN orders o ON o.click_id = c.click_id
  GROUP BY a.category, a.advertiser_name
),
ranked AS (
  SELECT *, RANK() OVER (PARTITION BY category ORDER BY spend DESC) AS rnk,
         ROUND(100.0 * spend / SUM(spend) OVER (PARTITION BY category), 1) AS share_of_category_pct
  FROM adv
)
SELECT category, rnk, advertiser_name, spend, attributed_order_value,
       ROUND(attributed_order_value / spend, 2) AS roas, share_of_category_pct
FROM ranked WHERE rnk <= 3
ORDER BY category, rnk;

-- name: q6_ab_test_readout
-- Ad-format experiment on restaurant_listing, 2026-09-07..2026-09-27, random 50/50 at impression level
SELECT i.variant,
       COUNT(*)                                        AS impressions,
       COUNT(c.click_id)                               AS clicks,
       COUNT(o.order_id)                               AS orders,
       ROUND(SUM(i.cpm_paid) / 1000.0, 2)              AS spend,
       COALESCE(SUM(o.order_value), 0)                 AS attributed_order_value,
       ROUND(100.0 * COUNT(c.click_id) / COUNT(*), 3)  AS ctr_pct,
       ROUND(100.0 * COUNT(o.order_id) / COUNT(c.click_id), 2) AS click_to_order_pct,
       ROUND(1000.0 * COUNT(o.order_id) / COUNT(*), 3) AS orders_per_1k_imps,
       ROUND(1000.0 * SUM(i.cpm_paid) / 1000.0 / COUNT(*), 2) AS cpm
FROM impressions i
LEFT JOIN clicks c ON c.impression_id = i.impression_id
LEFT JOIN orders o ON o.click_id = c.click_id
WHERE i.variant IS NOT NULL
GROUP BY i.variant
ORDER BY i.variant;

-- name: q7_wow_growth
-- Weekly revenue, WoW growth (LAG) and 4-week moving average
WITH w AS (
  SELECT date(date, '-' || ((CAST(strftime('%w', date) AS INTEGER) + 6) % 7) || ' days') AS week_start,
         SUM(cpm_paid) / 1000.0 AS revenue
  FROM impressions WHERE date BETWEEN '2026-01-05' AND '2026-09-27' GROUP BY 1
)
SELECT week_start, ROUND(revenue, 2) AS revenue,
       ROUND(100.0 * (revenue / LAG(revenue) OVER (ORDER BY week_start) - 1), 1) AS wow_pct,
       ROUND(AVG(revenue) OVER (ORDER BY week_start ROWS BETWEEN 3 PRECEDING AND CURRENT ROW), 2) AS ma4_revenue
FROM w
ORDER BY week_start;

-- name: q8_fix_list_roas_below_1
-- Advertisers with meaningful spend but ROAS < 1 (churn risk -> account-management list)
WITH adv AS (
  SELECT a.advertiser_name, a.category,
         ROUND(SUM(i.cpm_paid) / 1000.0, 2) AS spend,
         COALESCE(SUM(o.order_value), 0)    AS attributed_order_value
  FROM impressions i
  JOIN advertisers a ON a.advertiser_id = i.advertiser_id
  LEFT JOIN clicks c ON c.impression_id = i.impression_id
  LEFT JOIN orders o ON o.click_id = c.click_id
  WHERE i.date >= '2026-07-01'
  GROUP BY a.advertiser_name, a.category
)
SELECT advertiser_name, category, spend, attributed_order_value,
       ROUND(attributed_order_value / spend, 2) AS roas
FROM adv
WHERE spend >= 1500 AND attributed_order_value / spend < 1
ORDER BY spend DESC;

-- name: q9_revenue_concentration
-- How concentrated is revenue? cumulative share of top advertisers (window)
WITH adv AS (
  SELECT advertiser_id, SUM(cpm_paid) / 1000.0 AS spend FROM impressions GROUP BY advertiser_id
),
r AS (
  SELECT advertiser_id, spend, ROW_NUMBER() OVER (ORDER BY spend DESC) AS rn,
         SUM(spend) OVER (ORDER BY spend DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cum_spend,
         SUM(spend) OVER () AS total_spend
  FROM adv
)
SELECT rn AS top_n, ROUND(spend, 2) AS advertiser_spend, ROUND(100.0 * cum_spend / total_spend, 1) AS cum_share_pct
FROM r WHERE rn IN (1, 5, 10, 20, 30)
ORDER BY rn;
