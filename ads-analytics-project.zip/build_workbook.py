"""
build_workbook.py  ->  Ads_Analytics_Workbook.xlsx
Reads results/*.csv (from run_analysis.py) and builds a formula-driven workbook.
Blue font = inputs pulled from SQL results or assumptions; black = formulas.
"""
import json, sqlite3
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import LineChart, Reference
from openpyxl.utils import get_column_letter

R = "results/"
q1 = pd.read_csv(R + "q1_weekly_kpis.csv")
q2 = pd.read_csv(R + "q2_category_performance.csv")
q3 = pd.read_csv(R + "q3_slot_auction_health.csv")
q3b = pd.read_csv(R + "q3b_monthly_fill_by_slot.csv")
q4 = pd.read_csv(R + "q4_retention_by_cohort.csv")
q4b = pd.read_csv(R + "q4b_retention_by_category.csv")
q6 = pd.read_csv(R + "q6_ab_test_readout.csv").set_index("variant")

con = sqlite3.connect("ads.db")
recent = pd.read_sql("""
  SELECT s.slot_name, SUM(i.impressions_available) AS av, SUM(i.impressions_filled) AS fl
  FROM inventory i JOIN slots s USING(slot_id)
  WHERE i.date BETWEEN '2026-08-03' AND '2026-09-27' GROUP BY 1""", con).set_index("slot_name")
recent_cpm = pd.read_sql("""
  SELECT s.slot_name, SUM(i.cpm_paid)/COUNT(*) AS cpm
  FROM impressions i JOIN slots s USING(slot_id)
  WHERE i.date BETWEEN '2026-08-03' AND '2026-09-27' GROUP BY 1""", con).set_index("slot_name")
base_weekly_rev = float(q1.tail(8)["revenue"].mean())

# ---------- styles ----------
F = "Arial"
f_norm = Font(name=F, size=10)
f_bold = Font(name=F, size=10, bold=True)
f_title = Font(name=F, size=14, bold=True)
f_note = Font(name=F, size=9, italic=True, color="595959")
f_head = Font(name=F, size=10, bold=True, color="FFFFFF")
f_in = Font(name=F, size=10, color="0000FF")
fill_head = PatternFill("solid", fgColor="1F3864")
fill_key = PatternFill("solid", fgColor="FFFF00")
fill_tot = PatternFill("solid", fgColor="D9E1F2")
thin = Side(style="thin", color="BFBFBF")
box = Border(top=thin, bottom=thin, left=thin, right=thin)
PCT, PCT2, NUM, NUM2, INR = "0.0%", "0.00%", "#,##0", "#,##0.00", "#,##0"

wb = Workbook()

def sheet(name, widths, first=False):
    ws = wb.active if first else wb.create_sheet()
    ws.title = name
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    return ws

def put(ws, ref, val, font=f_norm, fmt=None, fill=None, wrap=False, bold=False, border=True):
    c = ws[ref]
    c.value = val
    c.font = Font(name=F, size=font.size, bold=(font.bold or bold), italic=font.italic, color=font.color)
    if fmt: c.number_format = fmt
    if fill: c.fill = fill
    if wrap: c.alignment = Alignment(wrap_text=True, vertical="top")
    if border and not font.italic: c.border = box
    return c

def header(ws, row, labels, start=1):
    for j, lab in enumerate(labels):
        c = ws.cell(row=row, column=start + j, value=lab)
        c.font, c.fill, c.border = f_head, fill_head, box
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

def title(ws, text, note):
    ws["A1"].value, ws["A1"].font = text, f_title
    ws["A2"].value, ws["A2"].font = note, f_note

NOTE = "SIMULATED data (1% sample of ad logs). Blue = input from SQL results / assumption; black = formula."

# =============== Summary (filled last for references) ===============
ws_s = sheet("Summary", [46, 22, 90], first=True)

# =============== KPI_Weekly ===============
ws = sheet("KPI_Weekly", [12, 12, 10, 9, 12, 14, 11, 12, 12, 9, 9, 10, 9, 10])
title(ws, "Weekly Ads P&L — KPI Dashboard", NOTE + " Source: q1_weekly_kpis. Full Mon-Sun weeks 5 Jan - 27 Sep 2026. Revenue in INR (sample).")
header(ws, 4, ["Week start", "Impressions", "Clicks", "Orders", "Ad revenue (INR)", "Attributed order value (INR)",
               "Active advertisers", "Inventory available", "Inventory filled",
               "CTR", "CPM (INR)", "Fill rate", "ROAS", "WoW revenue"])
r0 = 5
for k, row in q1.iterrows():
    r = r0 + k
    put(ws, f"A{r}", row.week_start, f_in)
    for col, key, fmt in [("B", "impressions", NUM), ("C", "clicks", NUM), ("D", "orders", NUM), ("E", "revenue", NUM),
                          ("F", "attributed_order_value", NUM), ("G", "active_advertisers", NUM), ("H", "available", NUM), ("I", "filled", NUM)]:
        put(ws, f"{col}{r}", float(row[key]) if key == "revenue" else int(row[key]), f_in, fmt)
    put(ws, f"J{r}", f"=C{r}/B{r}", fmt=PCT2)
    put(ws, f"K{r}", f"=E{r}/B{r}*1000", fmt=NUM2)
    put(ws, f"L{r}", f"=I{r}/H{r}", fmt=PCT)
    put(ws, f"M{r}", f"=F{r}/E{r}", fmt="0.00x")
    put(ws, f"N{r}", f"=E{r}/E{r-1}-1" if k > 0 else "n/a", fmt=PCT)
rl = r0 + len(q1) - 1
rt = rl + 1
put(ws, f"A{rt}", "Total / overall", f_bold, fill=fill_tot)
for col in "BCDEFHI":
    put(ws, f"{col}{rt}", f"=SUM({col}{r0}:{col}{rl})", f_bold, NUM, fill_tot)
put(ws, f"G{rt}", "n/a", f_bold, fill=fill_tot)
put(ws, f"J{rt}", f"=C{rt}/B{rt}", f_bold, PCT2, fill_tot)
put(ws, f"K{rt}", f"=E{rt}/B{rt}*1000", f_bold, NUM2, fill_tot)
put(ws, f"L{rt}", f"=I{rt}/H{rt}", f_bold, PCT, fill_tot)
put(ws, f"M{rt}", f"=F{rt}/E{rt}", f_bold, "0.00x", fill_tot)
put(ws, f"N{rt}", "", f_bold, fill=fill_tot)
ws.freeze_panes = "B5"

for anchor, col, ttl in [("P4", 5, "Weekly ad revenue (INR, sample)"), ("P22", 12, "Fill rate (inventory utilisation)")]:
    ch = LineChart()
    ch.title, ch.height, ch.width = ttl, 8.5, 17
    ch.add_data(Reference(ws, min_col=col, min_row=4, max_row=rl), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=r0, max_row=rl))
    ch.legend = None
    ws.add_chart(ch, anchor)

# =============== Category ===============
ws = sheet("Category", [20, 11, 12, 10, 9, 13, 16, 9, 10, 12, 9, 11, 30])
title(ws, "Category Performance — where to grow or fix", NOTE + " Source: q2_category_performance.")
put(ws, "A3", "Grow if ROAS >=", f_bold); put(ws, "B3", 3.0, f_in, "0.0x", fill_key)
put(ws, "C3", "Fix if ROAS <", f_bold); put(ws, "D3", 1.2, f_in, "0.0x", fill_key)
put(ws, "E3", "Big spend >=", f_bold); put(ws, "F3", 0.15, f_in, PCT, fill_key)
header(ws, 5, ["Category", "Advertisers", "Impressions", "Clicks", "Orders", "Spend (INR)", "Attributed order value (INR)",
               "CTR", "CPM (INR)", "Click-to-order", "ROAS", "Spend share", "Action"])
c0 = 6
for k, row in q2.iterrows():
    r = c0 + k
    put(ws, f"A{r}", row.category, f_in)
    for col, key in [("B", "advertisers"), ("C", "impressions"), ("D", "clicks"), ("E", "orders"), ("F", "spend"), ("G", "attributed_order_value")]:
        put(ws, f"{col}{r}", float(row[key]) if key == "spend" else int(row[key]), f_in, NUM)
    put(ws, f"H{r}", f"=D{r}/C{r}", fmt=PCT2)
    put(ws, f"I{r}", f"=F{r}/C{r}*1000", fmt=NUM2)
    put(ws, f"J{r}", f"=E{r}/D{r}", fmt=PCT)
    put(ws, f"K{r}", f"=G{r}/F{r}", fmt="0.00x")
    put(ws, f"L{r}", f"=F{r}/SUM($F${c0}:$F${c0+len(q2)-1})", fmt=PCT)
    put(ws, f"M{r}", f'=IF(K{r}>=$B$3,"Grow",IF(K{r}<$D$3,"Fix",IF(L{r}>=$F$3,"Optimise (high spend, mid ROAS)","Maintain")))')
cl = c0 + len(q2) - 1
ct = cl + 1
put(ws, f"A{ct}", "Total", f_bold, fill=fill_tot)
put(ws, f"B{ct}", "n/a", f_bold, fill=fill_tot)
for col in "CDEFG":
    put(ws, f"{col}{ct}", f"=SUM({col}{c0}:{col}{cl})", f_bold, NUM, fill_tot)
put(ws, f"H{ct}", f"=D{ct}/C{ct}", f_bold, PCT2, fill_tot)
put(ws, f"I{ct}", f"=F{ct}/C{ct}*1000", f_bold, NUM2, fill_tot)
put(ws, f"J{ct}", f"=E{ct}/D{ct}", f_bold, PCT, fill_tot)
put(ws, f"K{ct}", f"=G{ct}/F{ct}", f_bold, "0.00x", fill_tot)
put(ws, f"L{ct}", f"=SUM(L{c0}:L{cl})", f_bold, PCT, fill_tot)
put(ws, f"M{ct}", "", f_bold, fill=fill_tot)

# =============== Retention ===============
ws = sheet("Retention", [20, 12, 13, 13, 13, 11, 11, 11])
title(ws, "Advertiser Retention — still spending in the week starting day 30 / 60 / 90 after signup",
      NOTE + " Sources: q4, q4b. Cohorts with signup <= 26 Jun 2026 so day-90 is fully observed. Small cohorts: read as directional.")
def ret_block(top, label, df, key):
    header(ws, top, [label, "Advertisers", "Retained D30", "Retained D60", "Retained D90", "D30 %", "D60 %", "D90 %"])
    r1 = top + 1
    for k, row in df.iterrows():
        r = r1 + k
        put(ws, f"A{r}", row[key], f_in)
        for col, kk in [("B", "advertisers"), ("C", "retained_d30"), ("D", "retained_d60"), ("E", "retained_d90")]:
            put(ws, f"{col}{r}", int(row[kk]), f_in, NUM)
        for col, src in [("F", "C"), ("G", "D"), ("H", "E")]:
            put(ws, f"{col}{r}", f"={src}{r}/B{r}", fmt=PCT)
    rl2 = r1 + len(df) - 1
    rt2 = rl2 + 1
    put(ws, f"A{rt2}", "All", f_bold, fill=fill_tot)
    for col in "BCDE":
        put(ws, f"{col}{rt2}", f"=SUM({col}{r1}:{col}{rl2})", f_bold, NUM, fill_tot)
    for col, src in [("F", "C"), ("G", "D"), ("H", "E")]:
        put(ws, f"{col}{rt2}", f"={src}{rt2}/B{rt2}", f_bold, PCT, fill_tot)
    return rt2
end1 = ret_block(4, "Signup cohort", q4, "cohort_month")
ret_block(end1 + 3, "Category", q4b, "category")

# =============== Slots_Auction ===============
ws = sheet("Slots_Auction", [20, 11, 13, 13, 11, 13, 11, 10, 14, 13, 16])
title(ws, "Inventory Utilisation & Auction Health by Placement", NOTE + " Sources: q3, q3b. 'Recent' = 3 Aug - 27 Sep 2026.")
header(ws, 4, ["Placement", "Floor CPM (INR)", "Inventory available", "Inventory filled", "Avg bidders", "Single-bidder auctions",
               "Avg CPM (INR)", "Fill rate", "Price over floor", "Unfilled impressions", "Recent 8-wk fill rate"])
for k, row in q3.iterrows():
    r = 5 + k
    put(ws, f"A{r}", row.slot_name, f_in)
    put(ws, f"B{r}", int(row.floor_cpm), f_in, NUM)
    put(ws, f"C{r}", int(row.available), f_in, NUM)
    put(ws, f"D{r}", int(row.filled), f_in, NUM)
    put(ws, f"E{r}", float(row.avg_bidders), f_in, NUM2)
    put(ws, f"F{r}", float(row.single_bidder_pct) / 100, f_in, PCT)
    put(ws, f"G{r}", float(row.cpm), f_in, NUM2)
    put(ws, f"H{r}", f"=D{r}/C{r}", fmt=PCT)
    put(ws, f"I{r}", f"=G{r}/B{r}-1", fmt=PCT)
    put(ws, f"J{r}", f"=C{r}-D{r}", fmt=NUM)
    put(ws, f"K{r}", float(recent.loc[row.slot_name, "fl"] / recent.loc[row.slot_name, "av"]), f_in, PCT)
put(ws, "A10", "Monthly fill rate by placement (q3b)", f_bold, border=False)
slots_order = list(q3.slot_name)
header(ws, 11, ["Month"] + slots_order)
piv = q3b.pivot(index="month", columns="slot_name", values="fill_rate_pct")
for k, (m, row) in enumerate(piv.iterrows()):
    r = 12 + k
    put(ws, f"A{r}", m, f_in)
    for j, sname in enumerate(slots_order):
        put(ws, f"{get_column_letter(2 + j)}{r}", float(row[sname]) / 100, f_in, PCT)

# =============== Opp_Sizing ===============
ws = sheet("Opp_Sizing", [64, 16, 15, 15, 15, 4])
title(ws, "Opportunity Sizing — before building", NOTE + " Change the yellow cells; everything else recalculates.")
put(ws, "A4", "Global inputs", f_bold, border=False)
put(ws, "A5", "Sample rate (simulated logs = 1% of platform traffic)"); put(ws, "B5", 0.01, f_in, PCT, fill_key)
put(ws, "A6", "Weeks per year"); put(ws, "B6", 52, f_in, NUM)
put(ws, "A7", "Baseline avg weekly ad revenue, last 8 wks (sample INR)"); put(ws, "B7", round(base_weekly_rev, 2), f_in, NUM)
put(ws, "A8", "Baseline avg weekly ad revenue, platform-scaled (INR)"); put(ws, "B8", "=B7/B5", fmt=NUM)

put(ws, "A10", "LEVER 1 - Premium 'Sponsored Spotlight' placement on search_top (price lever; slot is sold out)", f_bold, border=False)
put(ws, "A11", "Weekly available impressions, search_top (sample, avg last 8 wks)"); put(ws, "B11", round(float(recent.loc["search_top", "av"]) / 8), f_in, NUM)
put(ws, "A12", "Current avg CPM, search_top (INR, last 8 wks)"); put(ws, "B12", round(float(recent_cpm.loc["search_top", "cpm"]), 2), f_in, NUM2)
put(ws, "A13", "Current fill rate, search_top (last 8 wks)"); put(ws, "B13", float(recent.loc["search_top", "fl"] / recent.loc["search_top", "av"]), f_in, PCT)
header(ws, 15, ["Scenario assumptions", "", "Conservative", "Base", "Optimistic"])
sc1 = [("Share of inventory carved out for premium", [0.10, 0.15, 0.20]),
       ("Premium fill (share of carved inventory sold at premium)", [0.50, 0.65, 0.80]),
       ("Premium CPM uplift vs current CPM", [0.25, 0.40, 0.55]),
       ("Leakage (share of price premium lost to discounts / budget shifting)", [0.40, 0.30, 0.20])]
for k, (lab, vals) in enumerate(sc1):
    r = 16 + k
    put(ws, f"A{r}", lab); put(ws, f"B{r}", "")
    for col, v in zip("CDE", vals):
        put(ws, f"{col}{r}", v, f_in, PCT, fill_key)
put(ws, "A21", "Outputs", f_bold, border=False)
out1 = [("Premium impressions sold / week (sample)", "=$B$11*{c}16*{c}17", NUM),
        ("Gross price uplift / week (sample INR)", "={c}22*$B$12*{c}18/1000", NUM),
        ("Net incremental revenue / week (sample INR)", "={c}23*(1-{c}19)", NUM),
        ("Net incremental revenue / week (platform INR)", "={c}24/$B$5", NUM),
        ("Annualised net incremental revenue (platform INR)", "={c}25*$B$6", NUM),
        ("Uplift as % of baseline ad revenue", "={c}24/$B$7", PCT2)]
for k, (lab, fml, fmt) in enumerate(out1):
    r = 22 + k
    put(ws, f"A{r}", lab); put(ws, f"B{r}", "")
    for col in "CDE":
        put(ws, f"{col}{r}", fml.format(c=col), fmt=fmt, bold=(k in (2, 4)))

put(ws, "A29", "LEVER 2 - Fill under-used home_banner inventory (demand lever)", f_bold, border=False)
put(ws, "A30", "Weekly available impressions, home_banner (sample, avg last 8 wks)"); put(ws, "B30", round(float(recent.loc["home_banner", "av"]) / 8), f_in, NUM)
put(ws, "A31", "Current fill rate, home_banner (last 8 wks)"); put(ws, "B31", float(recent.loc["home_banner", "fl"] / recent.loc["home_banner", "av"]), f_in, PCT)
put(ws, "A32", "Current avg CPM, home_banner (INR, last 8 wks)"); put(ws, "B32", round(float(recent_cpm.loc["home_banner", "cpm"]), 2), f_in, NUM2)
header(ws, 34, ["Scenario assumptions", "", "Conservative", "Base", "Optimistic"])
sc2 = [("Target fill rate", [0.75, 0.82, 0.90]),
       ("Price discount offered to win incremental demand", [0.30, 0.20, 0.10])]
for k, (lab, vals) in enumerate(sc2):
    r = 35 + k
    put(ws, f"A{r}", lab); put(ws, f"B{r}", "")
    for col, v in zip("CDE", vals):
        put(ws, f"{col}{r}", v, f_in, PCT, fill_key)
put(ws, "A38", "Outputs", f_bold, border=False)
out2 = [("Incremental impressions sold / week (sample)", "=$B$30*({c}35-$B$31)", NUM),
        ("Incremental revenue / week (sample INR)", "={c}39*$B$32*(1-{c}36)/1000", NUM),
        ("Incremental revenue / week (platform INR)", "={c}40/$B$5", NUM),
        ("Annualised incremental revenue (platform INR)", "={c}41*$B$6", NUM),
        ("Uplift as % of baseline ad revenue", "={c}40/$B$7", PCT2)]
for k, (lab, fml, fmt) in enumerate(out2):
    r = 39 + k
    put(ws, f"A{r}", lab); put(ws, f"B{r}", "")
    for col in "CDE":
        put(ws, f"{col}{r}", fml.format(c=col), fmt=fmt, bold=(k == 3))
put(ws, "A45", "COMBINED (Lever 1 + Lever 2)", f_bold, border=False)
put(ws, "A46", "Annualised incremental revenue (platform INR)", f_bold); put(ws, "B46", "")
put(ws, "A47", "Uplift as % of baseline ad revenue", f_bold); put(ws, "B47", "")
for col in "CDE":
    put(ws, f"{col}46", f"={col}26+{col}42", f_bold, NUM, fill_tot)
    put(ws, f"{col}47", f"={col}27+{col}43", f_bold, PCT2, fill_tot)
notes = [
    "Assumptions & logic:",
    "1) Lever 1: search_top is ~100% filled recently, so standard demand exceeds supply. Premium impressions sold DISPLACE standard ones (lost at current CPM);",
    "   unsold premium inventory reverts to standard and is backfilled. Gain = premium impressions x current CPM x uplift, less leakage.",
    "2) Lever 2: home_banner is under-filled with thin auctions (see Slots_Auction), so the lever is demand, not price: sell extra impressions at a discount.",
    "3) Scenario inputs are judgement calls (not from data). Test them with a pilot before committing. Sample rate scales sample INR to platform INR.",
]
for k, t in enumerate(notes):
    c = ws.cell(row=49 + k, column=1, value=t); c.font = f_bold if k == 0 else f_note

# =============== AB_Readout ===============
ws = sheet("AB_Readout", [58, 16, 16, 4])
title(ws, "A/B Test Readout — dish-image carousel ad format vs control (restaurant_listing, 7-27 Sep 2026)",
      NOTE + " Random 50/50 split at impression level. Source: q6_ab_test_readout.")
header(ws, 4, ["Inputs", "Control", "Treatment"])
inp = [("Impressions", "impressions"), ("Clicks", "clicks"), ("Orders", "orders"), ("Avg CPM (INR)", "cpm")]
for k, (lab, key) in enumerate(inp):
    r = 5 + k
    put(ws, f"A{r}", lab)
    for col, v in (("B", "control"), ("C", "treatment")):
        val = float(q6.loc[v, key]) if key == "cpm" else int(q6.loc[v, key])
        put(ws, f"{col}{r}", val, f_in, NUM2 if key == "cpm" else NUM)
put(ws, "A10", "Primary metric: click-through rate (CTR)", f_bold, border=False)
rows = [
    (11, "CTR", "=B6/B5", "=C6/C5", PCT2),
    (12, "Absolute difference", "", "=C11-B11", PCT2),
    (13, "Relative lift", "", "=C11/B11-1", PCT),
    (14, "Pooled proportion", "", "=(B6+C6)/(B5+C5)", "0.0000"),
    (15, "Standard error (pooled)", "", "=SQRT(C14*(1-C14)*(1/B5+1/C5))", "0.00000"),
    (16, "z-statistic", "", "=C12/C15", "0.00"),
    (17, "p-value (two-sided)", "", "=2*(1-NORMSDIST(ABS(C16)))", "0.000000"),
    (18, "Standard error (unpooled, for CI)", "", "=SQRT(B11*(1-B11)/B5+C11*(1-C11)/C5)", "0.00000"),
    (19, "95% CI lower, relative lift", "", "=(C12-1.96*C18)/B11", PCT),
    (20, "95% CI upper, relative lift", "", "=(C12+1.96*C18)/B11", PCT),
]
for r, lab, b, c, fmt in rows:
    put(ws, f"A{r}", lab, bold=(r in (13, 17))); put(ws, f"B{r}", b, fmt=fmt); put(ws, f"C{r}", c, fmt=fmt, bold=(r in (13, 17)))
put(ws, "A21", "Significance level (alpha)"); put(ws, "B21", ""); put(ws, "C21", 0.05, f_in, PCT, fill_key)
put(ws, "A23", "Guardrail: click-to-order rate", f_bold, border=False)
rows = [
    (24, "Click-to-order rate", "=B7/B6", "=C7/C6", PCT2),
    (25, "Absolute difference", "", "=C24-B24", PCT2),
    (26, "Pooled proportion", "", "=(B7+C7)/(B6+C6)", "0.0000"),
    (27, "Standard error (pooled)", "", "=SQRT(C26*(1-C26)*(1/B6+1/C6))", "0.00000"),
    (28, "z-statistic", "", "=C25/C27", "0.00"),
    (29, "p-value (two-sided)", "", "=2*(1-NORMSDIST(ABS(C28)))", "0.0000"),
]
for r, lab, b, c, fmt in rows:
    put(ws, f"A{r}", lab); put(ws, f"B{r}", b, fmt=fmt); put(ws, f"C{r}", c, fmt=fmt)
put(ws, "A31", "Guardrail power check (can we detect harm to conversion?)", f_bold, border=False)
rows = [
    (32, "Relative drop in click-to-order we must be able to detect", "", 0.15, PCT, True),
    (33, "Baseline click-to-order (control)", "", "=B24", PCT2, False),
    (34, "Rate under the 'drop' scenario", "", "=C33*(1-C32)", PCT2, False),
    (35, "Clicks needed per arm (80% power)", "", "=(NORMSINV(1-C21/2)*SQRT(2*((C33+C34)/2)*(1-(C33+C34)/2))+NORMSINV(0.8)*SQRT(C33*(1-C33)+C34*(1-C34)))^2/(C33-C34)^2", NUM, False),
    (36, "Clicks available per arm (smaller arm)", "", "=MIN(B6,C6)", NUM, False),
    (37, "Coverage of required sample", "", "=C36/C35", PCT, False),
]
for r, lab, b, c, fmt, is_in in rows:
    put(ws, f"A{r}", lab); put(ws, f"B{r}", b)
    put(ws, f"C{r}", c, f_in if is_in else f_norm, fmt, fill_key if is_in else None)
put(ws, "A39", "Readout", f_bold, border=False)
put(ws, "A40", '=IF(AND(C17<C21,C12>0),"Primary metric: SIGNIFICANT CTR lift of "&TEXT(C13,"0.0%")&" (95% CI "&TEXT(C19,"0.0%")&" to "&TEXT(C20,"0.0%")&")","Primary metric: NOT significant at the chosen alpha")', border=False)
put(ws, "A41", '=IF(C37<1,"Guardrail UNDERPOWERED: only "&TEXT(C37,"0%")&" of the clicks needed. Ship with monitoring or keep a 5-10% holdout.","Guardrail adequately powered")', border=False)
put(ws, "A42", '=IF(ABS(C8/B8-1)<0.02,"Auction price neutral: CPM differs by less than 2%.","CPM differs by more than 2%: investigate auction impact.")', border=False)

# =============== Metric_Defs ===============
ws = sheet("Metric_Defs", [26, 62, 52])
title(ws, "Metric Definitions (single source of truth for the ads P&L)", "Keep these stable; any change to a definition should be versioned and announced.")
header(ws, 4, ["Metric", "Definition", "Calculation"])
defs = [
    ("Impressions", "Ad shown in a placement after winning the auction", "COUNT(impressions)"),
    ("Ad revenue (spend)", "What advertisers pay; CPM is per 1,000 impressions", "SUM(cpm_paid) / 1000"),
    ("CPM (effective)", "Ad revenue per 1,000 impressions", "Ad revenue / impressions x 1000"),
    ("CTR", "Share of impressions that were clicked", "Clicks / impressions"),
    ("Click-to-order", "Share of clicks followed by an attributed order", "Orders / clicks"),
    ("Attributed order value", "Order value from orders attributed to an ad click", "SUM(orders.order_value)"),
    ("ROAS", "Advertiser return on ad spend (advertiser view)", "Attributed order value / ad revenue"),
    ("Fill rate", "Share of available inventory actually sold", "Impressions filled / impressions available"),
    ("Active advertisers", "Advertisers with at least one impression in the period", "COUNT(DISTINCT advertiser_id)"),
    ("Avg bidders", "Mean number of bidders per auction (competition depth)", "AVG(num_bidders)"),
    ("Single-bidder share", "Auctions with only one bidder; thin demand, weak price discovery", "Auctions with num_bidders = 1 / all auctions"),
    ("Price over floor", "Clearing price headroom above the reserve price", "Avg CPM / floor CPM - 1"),
    ("Day-N retention", "Advertiser still spending in the 7-day window starting N days after signup", "Any impression in [N, N+6] days after signup_date"),
    ("Sample rate", "Simulated logs are a 1% sample; scale to platform with 1 / sample rate", "Sample INR / 0.01"),
]
for k, (a, b, c) in enumerate(defs):
    r = 5 + k
    put(ws, f"A{r}", a, f_bold); put(ws, f"B{r}", b, wrap=True); put(ws, f"C{r}", c, wrap=True)

# =============== Summary content ===============
ws = ws_s
title(ws, "Ads Performance & Auction Health Analytics: Summary", "Simulated 1% sample of marketplace ad logs, Jan-Sep 2026, INR. Built with SQL (SQLite) + Python + this workbook.")
header(ws, 4, ["Headline KPI (5 Jan - 27 Sep 2026)", "Value", "Note"])
last = r0 + len(q1) - 1
kp = [
    ("Impressions (sample)", f"=KPI_Weekly!B{rt}", NUM, ""),
    ("Ad revenue (sample INR)", f"=KPI_Weekly!E{rt}", NUM, ""),
    ("Ad revenue (platform-scaled INR)", "=B6/Opp_Sizing!B5", NUM, "Sample / sample rate (1%)"),
    ("CTR", f"=KPI_Weekly!J{rt}", PCT2, ""),
    ("Effective CPM (INR)", f"=KPI_Weekly!K{rt}", NUM2, ""),
    ("ROAS (advertiser view)", f"=KPI_Weekly!M{rt}", "0.00x", ""),
    ("Fill rate, first week", f"=KPI_Weekly!L{r0}", PCT, "Week of 5 Jan"),
    ("Fill rate, latest week", f"=KPI_Weekly!L{last}", PCT, "Week of 21 Sep"),
    ("Active advertisers, latest week", f"=KPI_Weekly!G{last}", NUM, ""),
]
for k, (a, f, fmt, n) in enumerate(kp):
    r = 5 + k
    put(ws, f"A{r}", a); put(ws, f"B{r}", f, fmt=fmt); put(ws, f"C{r}", n, f_note, border=False)
put(ws, "A15", "Key findings (from this simulated dataset)", f_bold, border=False)
find = [
    "1. Inventory: fill rate rose from ~39% to ~92% as advertisers ramped. search_top and restaurant_listing are effectively sold out; home_banner is only ~69% filled with thin auctions (32% single-bidder).",
    "2. ROAS spread is wide: QSR Chains 4.6x vs Personal Care 0.78x. Snacks & FMCG is 24% of spend at only 1.46x, the biggest optimisation prize.",
    "3. Local Restaurants return 4.0x ROAS but only ~19% are still spending at day 90 (n=16): a retention problem, not a performance one. Health Foods is similar (14%, n=7).",
    "4. Personal Care (ROAS <1x) shows high retention so far (n=6): churn risk is delayed, so fix targeting before advertisers notice.",
    "5. A/B (dish-image carousel format): CTR +25% (95% CI +15% to +36%), CPM unchanged. The click-to-order guardrail is underpowered (only ~9% of the clicks needed), so ship with monitoring.",
    "6. Concentration: top 10 advertisers = ~40% of spend. See q9.",
    "7. Opportunity sizing is scenario-based (Opp_Sizing); inputs are assumptions, to be validated by a pilot.",
]
for k, t in enumerate(find):
    c = ws.cell(row=16 + k, column=1, value=t)
    c.font, c.alignment = f_norm, Alignment(wrap_text=True, vertical="top")
    ws.merge_cells(start_row=16 + k, start_column=1, end_row=16 + k, end_column=3)
    ws.row_dimensions[16 + k].height = 30

for w in wb.worksheets:
    w.sheet_view.showGridLines = False
wb.save("Ads_Analytics_Workbook.xlsx")
print("saved")
